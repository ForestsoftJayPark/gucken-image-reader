from mcp_image_reader import main

main()